<?php
use yii\helpers\Html;
/* @var $this yii\web\View */

$this->title = 'GEL-E-Portal';
//use yii\bootstrap\Html;
?>
<div class="site-index" >


    <div align="center"><?php // Html::img(Yii::$app->request->baseUrl.'/uploads/Logo.jpg',['class'=>'img-square','width'=>'600px']);?></div>
    <h1 class="text text-center">Welcome to G-Education Expenditure Portal</h1>



</div>
